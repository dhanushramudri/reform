import React from "react";
import mockup from "../images/mockup.jpg";

const Home = () => {
  return (
    <div className="App">
      <img src={mockup} alt="" />
      <h3>App</h3>
    </div>
  );
};

export default Home;
